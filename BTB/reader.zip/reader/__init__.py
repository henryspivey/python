from reader.reader import Reader
# hoist the reader class up here